Fahed Abudayyeh, Aaron Rodden

For this mini Minecraft Planner, we used an A* forward search approach.

Our heuristic function skips redundant states by not checking tool states for tools that are already available.
We also make sure to create the best tools we can by creating a heirarchy for pickaxes and axes when checking what tools to craft.